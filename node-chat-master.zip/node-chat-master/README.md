# Basic Node Chat which actually works

## Setup Instructions
- clone the repo `git clone https://github.com/hereshem/Node-Chat` or download zip
- run `node server.js`
- goto browser and type `http://localhost:3000`


## Informations
- No any library needed
- Runs on native node.js with version greater than 1.0
- Easy to understand and learn
- Based on long pooling

## Screenshots
![](welcome.png)

![](chat.png)
